﻿using Microsoft.AspNetCore.Identity;

namespace ToDoAPI.Authentication
{
    public class ApplicationUser : IdentityUser
    {
    }
}
